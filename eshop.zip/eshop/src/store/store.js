import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);
export default new Vuex.Store({
    state:{

        token:window.localStorage.getItem('id_token')?? '',
        email:window.localStorage.getItem('uid')?? '',
        inCart:JSON.parse(localStorage.getItem('myCart'))?JSON.parse(localStorage.getItem('myCart')):[]
    },
    getters:{
        inCart: state =>state.inCart
    },
    mutations:{
        tokenemail(state, payload){
            return state.token =payload.id, state.email=payload.uid;
        },
        ADD_TO_CART(state,id){ 
            state.inCart.push(id) 
        },
        logout :(state )=> {
            state.token ="",
            state.email="",
            state.users="",
            window.localStorage.removeItem('id_token'),
            window.localStorage.removeItem('uid'),
            window.localStorage.removeItem('users'),
            window.localStorage.removeItem('myCart'),
            window.localStorage.removeItem('myWish')
            window.localStorage.removeItem('total')
        },
        
        
    },
    actions:{
        token(context,payload){
            context.commit('tokenemail',payload)
        },
        logout({ commit }) {
            commit('logout')
            this.$router.push("/login");
        },
        addToCart(context,id) {context.commit('ADD_TO_CART',id)}
    }
})