import Vue from 'vue';
import Router from 'vue-router';
Vue.use(Router);
import Main from '../components/Main.vue'
import Contact from '../components/Contact.vue';
import Login from '../components/Login.vue';
import Checkout from '../components/Checkout.vue';
import Cart from '../components/Cart.vue';
import Product from '../components/Product.vue';
import Account from '../components/Account.vue';
import Changepassword from '../components/Changepassword.vue';
import Order from '../components/Order.vue'
import Cms from '../components/Cms.vue'
import Wishlist from '../components/Wishlist.vue'
import Track from '../components/Track.vue'
function myguard(to,from,next){
    let  isAuthenticated=false;
    if(localStorage.getItem('uid')  != undefined){
        isAuthenticated = true;
    }
    else {
        isAuthenticated=false;
    }
    if(isAuthenticated) {
        next();
    }
    else{
        alert('YOU NEED TO LOGIN');
        next('/login');
    }
}


export default new Router({
    routes: [
        {
            path: '/',
            name: 'Main',
            component: Main,
            
        },
        {
            path: '/contact',
            name: 'Contact',
            component: Contact
        },
        {
            path: '/login',
            name: 'Login',
            component: Login
        },
        {
            path: '/checkout',
            name: 'Checkout',
            beforeEnter:myguard,
            component: Checkout
        },
        {
            path: '/cart',
            name: 'Cart',
            component: Cart
        },
        {
            path: '/account',
            name: 'Account',
            beforeEnter:myguard,
            component: Account
        },
        {
            path: '/product/:id?',
            name: 'Product',
            component: Product,
            props:true
        },
        {
            path: '/changepassword',
            name: 'Changepassword',
            beforeEnter:myguard,
            component: Changepassword
        },
        {
            path: '/order',
            name: 'Order',
            beforeEnter:myguard,
            component: Order
        },
        {
            path: '/cms',
            name: 'Cms',
    
            component: Cms
        },
        {
            path: '/wishlist',
            name: 'Wishlist',
            beforeEnter:myguard,
            component: Wishlist
        },
        {
            path: '/track',
            name: 'Track',
            beforeEnter:myguard,
            component: Track
        },
       
    ]
})