<template>
  <div class="container">
     <label> Search </label><br>
      <input type="text" class="form-control" placeholder="Tracking id" v-model="query"><br>
      <input type="button" value="submit" class="btn btn-success" @click="search()"><br><br>
      
      <p v-if="store">
        <section class="container">
      <table class="table table-striped table-bordered">
        <thead>
          <tr>
              <th>Name</th>
             
            <th>quantity</th>
            <th>price</th>
            <th>total</th>
            <th>status</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="storedata in store" :key="storedata.id">
                <td>{{storedata.name}}</td>
              
                 <td>{{storedata.quantity}}</td>
                  <td>{{storedata.price}}</td>
                  <td>{{storedata.quantity*storedata.price}}</td>
                    <section v-if="storedata.status=='processing'">
                        <td class="text text-danger">{{ storedata.status}}</td>
                    </section>
                     <section v-else>
                        <td class="text text-success">{{ storedata.status}}</td>
                    </section>
                  
            </tr>
            </tbody>
      </table>
    </section>
      </p>
      
  </div>
</template>

<script>
import axios from 'axios';
import { MAIN_URL } from '@/common/Url';
export default {
name:"Track",
data(){
    return{
        store:undefined,
        query:null,
       
    }
},
methods:{
    search(){
         axios.get(`${MAIN_URL}track/`+ this.query)
  .then((res) => {
    if(res.data.err==0){
      this.store=res.data.track
      console.log(this.orderdata)
    }
  })
    }
}
}
</script>

<style>

</style>