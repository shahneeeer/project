<template>
<div>
      <section id="cart_items">
    <div class="container">
      <div class="breadcrumbs">
        <ol class="breadcrumb">
          <li><a href="#">Home</a></li>
          <li class="active">Shopping Cart</li>
        </ol>
      </div>
      <div class="table-responsive cart_info">
        <table class="table table-condensed">
          <thead>
            <tr class="cart_menu" >
              <td class="image">Item</td>
              <td class="description">Name</td>
              <td class="price">Price</td>
              <td class="quantity">Quantity</td>
              <td class="total">Total</td>
              <td></td>
            </tr>
          </thead>
          <tbody>
            <tr v-for="product in item" :key="product.id">
              <td class="cart_product">
                <a href=""><img v-bind:src="server + product.image" height="100" width="100" alt="" /></a>
              </td>
              <td class="cart_description">
                <h4><a href="">{{product.name}}</a></h4>
                <p></p>
              </td>
              <td class="cart_price">
                <p>{{product.price}}</p>
              </td>
              <td >
                <div >
                  <button  @click="addQty(product)">+</button>
                  
                       {{product.quantity}}
                  
                  <button  @click="subQty(product)">-</button>
                </div>
              </td>
              <td class="cart_total">
                  
                <p class="cart_total_price">{{product.price * product.quantity}}</p>
              </td>
              <td >
                <button class="btn btn-danger"
                  ><i @click="delItem(product)">delete</i
                ></button>
              </td>
            </tr>
            
        
        

           
             
              
          </tbody>
        </table>
      </div>
    </div>
  </section>
  <!--/#cart_items-->

  <section id="do_action">
    <div class="container">
      <div class="heading">
     
      </div>
      <div class="row">
        <div class="col-sm-6">
          <div class="chose_area">
            <ul class="user_option">
              <li>
                <input>
                <label>Use Coupon Code

                </label>
                
                  <div v-for="coupon in coudata" :key="coupon.id">
                    {{coupon.code}}
                    {{coupon.value}}
                  </div>
              </li>
            
            </ul>
          
          
           
            <a class="btn btn-default update" href="">Get Quotes</a>
            <a class="btn btn-default check_out" href="">Continue</a>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="total_area">
            <ul>
              
              <li> <h2>Rs {{ check() }}</h2> </li>
            </ul>
            
            <router-link class="btn btn-default check_out" to="/checkout">Check Out</router-link>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/#do_action-->
</div>
</template>

<script>
import { coupon } from "@/common/Service";
export default {
  name: "Cart",
  data() {
    return {
      item: undefined,
      server: "http://127.0.0.1:8000/product/",
      total: 0,
      coudata:undefined,
    };
  },
  mounted() {
    (this.item = JSON.parse(localStorage.getItem("myCart"))),
      coupon().then((res) => {
        if (res.data.err == 0) {
          this.coudata = res.data.coupon;
          console.log(res.data.coupon);
        }
      });
  },
  methods: {
    addQty(product) {
      Object.assign(product, {
        quantity: parseInt(product.quantity) + 1,
      });
      this.total += product.quantity * product.price;

      localStorage.setItem("myCart", JSON.stringify(this.item));
    },
    subQty(product) {
      Object.assign(product, {
        quantity: parseInt(product.quantity) - 1,
      });
      if (product.quantity < 1) {
        this.$swal("product cant be negative","","error")
        let cart = this.item.indexOf(product);
        this.item.splice(cart, 1);
        localStorage.setItem("myCart", JSON.stringify(this.item));
      }
      this.total -= product.quantity * product.price;
      localStorage.setItem("myCart", JSON.stringify(this.item));
    },
    delItem(product) {

      let cart = this.item.indexOf(product);
      console.log(cart);
      this.item.splice(cart, 1);
      localStorage.setItem("myCart", JSON.stringify(this.item));
    },
    check(){
      const items=JSON.parse(localStorage.getItem('myCart'));
      var sum=0;
      items.forEach((product) =>{
        sum=sum+product.price*product.quantity;
      });
      localStorage.setItem('total',JSON.stringify(sum));
      return sum;
    }
  },
  
};
</script>

<style>
</style>