<template>
  <section id="form">
    <!--form-->
    <div class="container">
      <div class="row">
        <div class="col-sm-4 col-sm-offset-1">
          <div class="login-form">
            <!--login form-->
            <h2>Login to your account</h2>
            <form @submit.prevent="postLogin()">
              <input
                type="email"
                placeholder="Email Address"
                v-model="emailLogin"
              />
              <input
                type="password"
                placeholder="Email Password"
                v-model="passwordLogin"
              />
             
              <button type="submit" class="btn btn-default">Login</button>
            </form>
          </div>
          <!--/login form-->
        </div>
        <div class="col-sm-1">
          <h2 class="or">OR</h2>
        </div>
        <div class="col-sm-4">
          <div class="signup-form">
            <!--sign up form-->
            <h2>New User Signup!</h2>
            <form @submit.prevent="postRegister()">
              <input type="text" placeholder="Firstname" v-model="fname" />
                 <input type="text" placeholder="lastname" v-model="lname" />
              <input type="email" placeholder="Email Address" v-model="email" />
              <input
                type="password"
                placeholder="Password"
                v-model="password"
              />
              <button type="submit" class="btn btn-default">Signup</button>
            </form>
          </div>
          <!--/sign up form-->
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { userLogin } from "@/common/Service";
import { userRegister } from "@/common/Service";
import { saveToken } from "@/common/Jwttoken";
import store from '../store/store';
import * as type from '../store/types';
import {mapState} from 'vuex';


export default {
  name: "Login",
  data() {
    return {
      emailLogin: null,
      passwordLogin: null,
      fname: null,
      lname:null,
      email: null,
      password: null,
    };
  },
  computed: mapState({
    token: (state) => state.token,
    email: (state) => state.email,
  }),
  methods: {
    postLogin() {
      let formData = { email: this.emailLogin, password: this.passwordLogin };
      userLogin(formData)
        .then((res) => {
          if (res.data.err == 0) {
            saveToken(res.data.token);
       
            this.$swal(res.data.msg,"","success");
            var bcd=res.data.users.id;
            localStorage.setItem('uid',res.data.email);
            var abc= res.data.users.firstname+res.data.users.lastname+bcd;
           
            localStorage.setItem('users',abc);
            
            console.log(res.data.users);
            this.$router.push({path: '/'});
            store.dispatch({
              type:type.Tokenemail,
              id:res.data.token,
              uid:res.data.email,
            });
        
          }
          if (res.data.err == 1) {
            alert(res.data.msg);
          }
        })
        .catch((err) => {
          console.log("SOmething Wrong " + err);
        });
    },
    postRegister() {
      let form = {
        firstname: this.fname,
        lastname:this.lname,
        email: this.email,
        password: this.password,
      };
      userRegister(form)
       .then((res) => {
          if (res.data.err == 0) {
         
           this.$swal(res.data.msg,"","success")
          }
         
        })
        .catch((err) => {
          console.log("SOmething Wrong " + err);
        });
      
    },
  },
};
</script>

<style>
</style>