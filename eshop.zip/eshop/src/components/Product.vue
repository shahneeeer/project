<template>
  <section>
    <div class="container">
      <div class="row">
        <Sidebar />

        <div class="col-sm-9 padding-right">
          <div class="features_items">
            <!--features_items-->
            <h2 class="title text-center">Features Items</h2>
            <div v-for="product of prodata" :key="product.id" class="col-sm-4">
              <div class="product-image-wrapper">
                <div class="single-products">
                  <div class="productinfo text-center">
                    <img
                      v-bind:src="server + product.image"
                      height="200"
                      alt=""
                    />
                    <h2></h2>
                    <b>{{ product.name }}</b>
                    <p>{{ product.type }}</p>
                    <p>{{ product.price }}</p>
                    <a href="#" class="btn btn-default add-to-cart"
                      ><i class="fa fa-shopping-cart"></i>Add to cart</a
                    >
                  </div>
                  <div class="product-overlay">
                    <div class="overlay-content">
                      <h2>{{ product.price }}</h2>
                      <p></p>
                      <button class="btn btn-default add-to-cart" @click="addToCart(product)"
                        ><i class="fa fa-shopping-cart"></i>Add to cart</button
                      >
                    </div>
                  </div>
                </div>
                <div class="choose">
                  <ul >
                    <li>
                      <button class="btn btn-defailt" @click="addToWish(product)"
                        ><i class="fa fa-plus-square"></i>Add to wishlist</button
                      >
                    </li>
                   
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!--features_items-->
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { product } from "@/common/Service";
import Sidebar from "./includes/Sidebar.vue";
import axios from 'axios';

export default {
  components: { Sidebar },
  name: "Product",
  props:['id'],

  data() {
    return { prodata: undefined, server: "http://127.0.0.1:8000/product/" };
  },
  methods: {
    addToCart(product)
 {
      if (localStorage.getItem("myCart") != undefined) {
        let arr = JSON.parse(localStorage.getItem("myCart"));
        let obj = { pid: product.id, quantity: 1,name:product.name,price:product.price,image:product.image };
        const found=arr.some((el) => el.pid == product.id);
        if(found){
         this.$swal("product is in the cart","","error");
          }
        else{
             arr.push(obj);
            localStorage.setItem("myCart", JSON.stringify(arr));
            this.$store.dispatch("addToCart", arr);
              this.$swal("product added to cart","","success");
          }
        
      } else {
        let arr = [];
        let obj = { pid: product.id, quantity: 1,name:product.name,price:product.price,image:product.image };
        arr.push(obj);
        localStorage.setItem("myCart", JSON.stringify(arr));
        this.$store.dispatch("addToCart", arr);
        
      }
    },
    addToWish(product){
       let arr = [];
        let obj = { pid: product.id, quantity: 1,name:product.name,price:product.price,image:product.image };
        arr.push(obj);
        localStorage.setItem("myWish", JSON.stringify(arr));
    }
  },
  watch: {
    $route(to) {
      this.params = to.params.id;
      //  console.log(this.params);
      const url = "http://127.0.0.1:8000/api/catpro/";
      axios.get(`${url}` + this.params).then((res) => {
        this.prodata = res.data.product;
      });
    },
  },
  mounted() {
    product().then((res) => {
      if (res.data.err == 0) {
        this.prodata = res.data.product;
        console.log(res.data.product);
      }
    });
  },
};
</script>


<style>
</style>