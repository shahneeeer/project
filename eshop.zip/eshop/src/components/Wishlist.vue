<template>
   <div class="table-responsive cart_info">
        <table class="table table-condensed">
          <thead>
            <tr class="cart_menu" >
              <td class="image">Item</td>
              <td class="description">Name</td>
              <td class="price">Price</td>
            
           
              <td></td>
            </tr>
          </thead>
          <tbody>
            <tr v-for="product in item" :key="product.id">
              <td class="cart_product">
                <a href=""><img v-bind:src="server + product.image" height="100" width="100" alt="" /></a>
              </td>
              <td class="cart_description">
                <h4><a href="">{{product.name}}</a></h4>
                <p></p>
              </td>
              <td class="cart_price">
                <p>{{product.price}}</p>
              </td>
            
             
             
            </tr>
            
        
        

           
             
              
          </tbody>
        </table>
      </div>
</template>

<script>
export default {
name:"wishlist",
data(){
 return  {item:undefined,
    server:"http://127.0.0.1:8000/product/",
   
    }
},
mounted(){
      this.item =JSON.parse(localStorage.getItem('myWish'))
}
}
</script>

<style>

</style>