<template>
  <div class="container">
      <table class="table table-striped table-bordered">
        <thead>
          <tr>
              <th>Name</th>
              <th>order_id</th>
            <th>quantity</th>
            <th>price</th>
            <th>total</th>
           
            </tr>
        </thead>
        <tbody>
            <tr v-for="order in orderdata" :key="order.id">
                <td>{{order.name}}</td>
                <td>{{ order.order_id}}</td>
                 <td>{{order.quantity}}</td>
                  <td>{{order.price}}</td>
                  <td>{{order.quantity*order.price}}</td>
                 
            </tr>
            </tbody>
      </table>
    </div>
</template>

<script>
import axios from 'axios';
import { MAIN_URL } from '@/common/Url';

export default {
name:"order",
data(){
    return{
      idi:localStorage.getItem('uid'),
        orderdata:undefined,
    }
},

mounted(){
  axios.get(`${MAIN_URL}order/`+ this.idi)
  .then((res) => {
    if(res.data.err==0){
      this.orderdata=res.data.order
      console.log(this.orderdata)
    }
  })
}
}
</script>

<style>

</style>