<template>
  <section>
    <Slider />
    <section>
      <div class="container">
        <div class="row">
          
          <div class="col-sm-9 padding-right">
            <div class="features_items">
              <!--features_items-->
              <h2 class="title text-center">Features Items</h2>
              <h1>{{id}}</h1>
             <div v-for="product of prodata" :key="product.id" class="col-sm-4">
              <div class="product-image-wrapper">
                <div class="single-products">
                  <div class="productinfo text-center">
                    <img v-bind:src="server + product.image"  height="200" alt="" />
                    <h2></h2>
                    <b>{{product.name}}</b>
                    <p>{{product.type}}</p>
                    <p>{{product.price}}</p>
                    <a href="#" class="btn btn-default add-to-cart"
                      ><i class="fa fa-shopping-cart"></i>Add to cart</a
                    >
                  </div>
                  <div class="product-overlay">
                    <div class="overlay-content">
                      <h2>{{product.price}}</h2>
                      <p></p>
                      <a href="#" class="btn btn-default add-to-cart"
                        ><i class="fa fa-shopping-cart"></i>Add to cart</a
                      >
                    </div>
                  </div>
                </div>
                <div class="choose">
                  <ul class="nav nav-pills nav-justified">
                    <li>
                      <a href=""
                        ><i class="fa fa-plus-square"></i>Add to wishlist</a
                      >
                    </li>
                    <li>
                      <a href=""
                        ><i class="fa fa-plus-square"></i>Add to compare</a
                      >
                    </li>
                  </ul>
                </div>
              </div>
            </div>

              <!--features_items-->
            </div>
          </div>
        </div>
      </div>
    
    </section>
  </section>
</template>

<script>
import Slider from "./includes/Slider.vue";

import { product } from "@/common/Service";

export default {
  name: "Main",
props:['id'],
  data() {
    return { 
      prodata:undefined,
      server: "http://127.0.0.1:8000/product/" };
  },

  components: {
    Slider,
    
  },
  mounted() {
    product().then((res) => {
      if (res.data.err == 0) {
        this.prodata = res.data.product;
        console.log(res.data.product);
      }
    });
  },
};
</script>

<style>
</style>