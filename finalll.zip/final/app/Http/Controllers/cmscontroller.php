<?php

namespace App\Http\Controllers;
use App\Models\cms;
use Illuminate\Http\Request;

class cmscontroller extends Controller
{
    public function cms(){
        return view('cms.incms');
    }
    public function incms(Request $req){
        $validator=$req->validate([
            'title'=>'required',
            'body'=>'required',
        ],[
            'title.required'=>'This field is mandatory',
            'body.required'=>'This field is mandatory'
        ]);
        if($validator){
            cms::insert([
                'title'=>$req->title,
                'body'=>$req->body,  
            ]);
            return redirect('/scms');
        }

    }
    public function scms(){
        $cms=cms::all();
        return view('cms.scms',compact('cms'));
    }
    public function ecms($id){
        $cms=cms::find($id);
        return view('cms.ucms',compact('cms'));
    }
    public function ucms(Request $req){
        cms::where('id',$req->id)->update([
            'title'=>$req->title,
            'body'=>$req->body,
     
    
        ]);
        return redirect('/scms');
    }
    public function delcms($id){
        cms::find($id)->delete();
       return redirect('/scms');
    }
    
}
