<?php

namespace App\Http\Controllers;
use App\Models\slider;
use Illuminate\Support\Facades\File;

use Illuminate\Http\Request;

class Slidercontroller extends Controller
{
    public function index(){
        $data=slider::all();
        return view ('Bannner.slider',compact('data'));
    }
    public function addslider(){
        return view ('Bannner.addslider');
    }
    public function insertslider(Request $req){
        $validate=$req->validate([
            'heading'=>'required',
            'description'=>'required',
            'image'=>'required',
        ],[
            'heading.required'=>'This field is mandatory',
            'description.required'=>'This field is mandatory',
            'image.required'=>'This field is mandatory',
        ]);
        if($validate){
          $slider=new slider();
          $slider->heading=$req->input('heading');
          $slider->description=$req->input('description');
          if($req->hasFile('image')){
              $file=$req->file('image');
              $extension=$file->getClientOriginalExtension();
              $filename=time()."-".$extension;
              $file->move('uploads',$filename);
              $slider->image=$filename;

          }
          $slider->status=$req->input('status') ==true ? '1':'0';
          $slider->save();

        }
        return redirect('/slider');
    }
    public function edit($id){
        $data=slider::find($id);
        return view('Bannner.edit',compact('data'));
    }
  
    public function updateslider(Request $req)
    {
        $validate = $req->validate([
            'heading' => 'required',
            'description' => 'required',
            'image' => 'required',
        ], [
            'heading.required' => 'This field is mandatory',
            'description.required' => 'This field is mandatory',
            'image.required' => 'This field is mandatory',
        ]);
        if ($validate) {

            $slider = slider::findOrFail($req->id);

            $slider->heading = $req->input('heading');
            $slider->description = $req->input('description');
            if ($req->hasFile('image')) {
                $destination = 'uploads/' . $slider->image;
                if (File::exists($destination)) {
                    File::delete($destination);
                }
                $file = $req->file('image');
                $extension = $file->getClientOriginalExtension();
                $filename = time() . "-" . $extension;
                $file->move('uploads', $filename);
                $slider->image = $filename;
            }
            $slider->status = $req->input('status') == true ? '1' : '0';
            $slider->save();
        }
        return redirect('/slider');
    }
}
