<?php

namespace App\Http\Controllers;
use App\Models\role;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Models\contact;
use App\Models\Checkout;
use App\Models\orders;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class admin extends Controller
{
    public function contact(){
        $user=contact::all();
        return view('contact',compact('user'));
    }
    public function checkout(){
        $checkout=Checkout::all();
        return view('order.address',compact('checkout'));
    }
    //order
    public function order(){
        $order=orders::all();
        return view('order.orders',compact('order'));
    }
    public function edit($id){
        $order=orders::find($id);
        return view('order.uorder',compact('order'));
    }
    public function update(Request $req){
        orders::where('id',$req->id)->update([
            
            'status'=>$req->status,
            'order_id' =>$req->order,
        ]);
        return redirect('/order');
    }
    public function regusers()
    {
        $userCount = User::where('role', 'Customer')->count();
        $orderCount = orders::count();

        return view('chart', compact('userCount', 'orderCount'));
    }
//////////////////////////////



    public function user(){
        return view('user');
    }
    //To fetch roles in user table
    public function role(){
        $data=role::all();
     
        return view('user',compact('data'));
    }
    //insert user in users table
    public function insertuser(Request $req){
        $validate=$req->validate([
            'fname'=>'required',
            'lname'=>'required',
            'email'=>'required',
            'pass'=>'min:9|required_with:cpass|same:cpass',
            'cpass'=>'required|min:9',
            'status'=>'required',
            'roles'=>'required',
        ],[
            'fname.required'=>'This field is manadtory',
            'lname.required'=>'This field is manadtory',
            'email.requires'=>'This field is manadtory',
            'pass.required'=>'This field is manadtory',
            'cpass.required'=>'This field is manadtory',
            'status.required'=>'This field is manadtory',
            'roles.required'=>'This field is manadtory',
        ]);
        if($validate){
            User::insert([
                'firstname'=>$req->fname,
                'lastname'=>$req->lname,
                'email'=>$req->email,
                'password'=>Hash::make($req->pass),
                'active'=>$req->status,
                'role'=>$req->roles,
                
            ]);
           // return back()->with('success',"DATA SAVED SUCESSFULLY");
            return redirect('/show');
        }
    }
    //fetch users in table
    public function showuser(){
        $user=User::all();
        return view('showuser',compact('user'));
    }
    //delete users
    public function deleteuser($id){
        User::find($id)->delete();
        return redirect('/show');
    }
    //edit user
    public function edituser($id){
        $data=role::all();
        $use=User::find($id);
        return view('edituser',compact('use','data'));
    }
    //update user
   public function updateuser(Request $req){
    User::where('id',$req->id)->update([
        'firstname'=>$req->fname,
        'lastname'=>$req->lname,
        'email'=>$req->email,
        'active'=>$req->status,
        'role'=>$req->roles,

    ]);
    return redirect('/show'); 
   }
    
    
    
}
