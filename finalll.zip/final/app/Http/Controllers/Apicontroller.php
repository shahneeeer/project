<?php

namespace App\Http\Controllers;
use App\Models\product;
use App\Http\Resources\taskresource;
use App\Models\category;
use App\Models\slider;
use App\Models\orders;
use App\Models\cms;
use App\Models\User;
use App\Models\Coupon;
use Illuminate\Http\Request;

class Apicontroller extends Controller
{
    public function product(){
        $product=product::all();
        return response(['product'=> taskresource::collection($product),'err'=> 0]);
    }
    public function slider(){
        $slider=slider::all();
        return response(['slider'=> taskresource::collection($slider),'err'=> 0]);

    }
    public function category(){
        $category=category::all();
        return response(['category'=> taskresource::collection($category),'err'=> 0]);  
    }
    public function catpro($id){
        $product=product::where('category_id',$id)->get();
        return response(['product'=> taskresource::collection($product),'err'=> 0]);

    }
    public function coupon(){
        $coupon=Coupon::all();
        return response(['coupon'=> taskresource::collection($coupon),'err'=> 0]);
    }
    public function order($id){ 
      
        $user=User::where('email',$id)->first();
       
        $order=orders::where('user_id',$user->id)->get();
        return response(['order'  => taskresource::collection($order), 'msg' =>'sucess','err' =>0]);
    }
    public function cms(){
        $cms=cms::all();
        return response(['cms'=> taskresource::collection($cms),'err'=> 0]);
    }
    public function track($id){
       
        $order=orders::where('order_id',$id)->get();
        return response(['track'  => taskresource::collection($order), 'msg' =>'sucess','err' =>0]);
    }
}
