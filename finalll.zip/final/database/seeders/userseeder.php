<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

use Illuminate\Database\Seeder;

class userseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'firstname'=>'Admin',
            'lastname'=>'admin',
            'email'=>'neershah70457@gmail.com',
            'password'=>Hash::make('admin@123'),
            'active'=>1,
            'role'=>'admin'
        ]);
    }
}
